package br.com.fiap.model;

public class Dentista {
}
