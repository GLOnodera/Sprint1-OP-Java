package br.com.fiap.dto;

public class PacienteDTO {
}
